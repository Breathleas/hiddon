//
// main.c
// swinjector
//
// Created by rainyx on 13-7-24.
// Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <mach/mach.h>
#include <mach/machine/thread_status.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>

#define CPSR_T_MASK (1u<<5)

struct INJECT_CONTEXT
{
    void* _pthreadStruct;
    void (*__pthread_set_self)(pthread_t);
    int (*pthread_create)(pthread_t *, const pthread_attr_t *, void *(*)(void *), void *);
    int (*pthread_join)(pthread_t, void **);
    mach_port_t (*mach_thread_self)();
    kern_return_t (*thread_terminate)(thread_act_t);
    const char *library;
    void *(*dlopen)(const char *, int);
} INJECT_CONTEXT;

static void* stub_thread_code(struct INJECT_CONTEXT* data);

static void stub_code_start(struct INJECT_CONTEXT* data)
{
    while(1);
    
    *(size_t*)data->_pthreadStruct = data->_pthreadStruct;
    
    data->__pthread_set_self(data->_pthreadStruct);
    
    pthread_t thread;
    data->pthread_create(&thread, 0, stub_thread_code, data);
    
    void* retval;
    data->pthread_join(thread, &retval);
    
    data->thread_terminate(data->mach_thread_self());
}

static void* stub_thread_code(struct INJECT_CONTEXT* data)
{
    data->dlopen(data->library, RTLD_NOW);
    
    return NULL;
}

static void stub_code_end(){};



uint64_t find_gadget_candidate(char** alternatives, size_t gadget_length)
{
    void* haystack_start = (void*)dlsym(RTLD_DEFAULT, "_dyld_start");    // will do...
    size_t haystack_size = 100*1024*1024; // likewise...

    for (char* candidate = *alternatives; candidate != NULL; alternatives++) {
        void* found_at = memmem(haystack_start, haystack_size, candidate, gadget_length);
        if (found_at != NULL){
            printf("found at: %llx\n", (uint64_t)found_at);
            return (uint64_t)found_at;
        }
    }

    return 0;
}

uint64_t find_blr_x0_gadget()
{
    static uint64_t blr_x0_addr = 0;
    if (blr_x0_addr != 0){
        return blr_x0_addr;
    }
    char* blr_x19 = "\x00\x00\x3f\xd6";
    char* candidates[] = {blr_x19, NULL};
    blr_x0_addr = find_gadget_candidate(candidates, 4);
    if(!blr_x0_addr) {
        printf("cannot find blr_x0 gadget!\n");
        abort();
    }
    return blr_x0_addr;
}

uint64_t find_blr_x19_gadget()
{
    static uint64_t blr_x19_addr = 0;
    if (blr_x19_addr != 0){
        return blr_x19_addr;
    }
    char* blr_x19 = "\x60\x02\x3f\xd6";
    char* candidates[] = {blr_x19, NULL};
    blr_x19_addr = find_gadget_candidate(candidates, 4);
    if(!blr_x19_addr) {
        printf("cannot find blr_x19 gadget!\n");
        abort();
    }
    return blr_x19_addr;
}

uint64_t find_syscall_gadget()
{
    static size_t syscall_addr=0;
    if (syscall_addr != 0){
        return syscall_addr;
    }
    char* blr_x19 = "\x01\x10\x00\xD4";
    char* candidates[] = {blr_x19, NULL};
    syscall_addr = find_gadget_candidate(candidates, 4);
    if(!syscall_addr) {
        printf("cannot find syscall gadget!\n");
        abort();
    }
    return syscall_addr;
}

int main123145 (int argc, const char * argv[])
{
    if(argc!=3)
    {
        printf("Usage: <PID> <Dynamic library path>\n");
        return 0;
    }
    
    const char *library = argv[2];
    
    pid_t pid = (pid_t)strtoul(argv[1], NULL, 10);
}

int mainchroot2(pid_t pid , char *library)
{
    mach_port_t self = mach_task_self();
    mach_port_t remoteTask;
    
    kern_return_t krr;
    krr = task_for_pid(mach_task_self(), pid, &remoteTask);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: task_for_pid %d, err=%d(%s)\n", pid, krr, mach_error_string(krr));
        return 0;
    }
    
    printf("process %d task=%x\n", pid, remoteTask);
    
    
    krr = mach_port_insert_right(mach_task_self(), remoteTask, remoteTask, MACH_MSG_TYPE_COPY_SEND);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_port_insert_right, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    // 分配栈空间
    vm_address_t remoteStack;
    vm_size_t stackSize = 16*1024;
    krr = vm_allocate(remoteTask, &remoteStack, stackSize, VM_FLAGS_ANYWHERE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    krr = vm_protect(remoteTask, remoteStack, stackSize, FALSE, VM_PROT_READ | VM_PROT_WRITE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_protect, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    printf("stack=%lx\n", remoteStack);
    
    // 写入library字符串
    vm_size_t libraryLen = strlen(library);
    vm_address_t remoteLibrary;
    krr = vm_allocate(remoteTask, &remoteLibrary, libraryLen, VM_FLAGS_ANYWHERE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = vm_write(remoteTask, remoteLibrary, library, (mach_msg_type_number_t)libraryLen);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    // 分配_pthread struct空间
    vm_address_t remotePthreadStruct;
    vm_size_t pthreadStructSize = 1024;
    krr = vm_allocate(remoteTask, &remotePthreadStruct, pthreadStructSize, VM_FLAGS_ANYWHERE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    // 写入Context
    struct INJECT_CONTEXT context;
    
    extern void _pthread_set_self(pthread_t);
    
    context.library = remoteLibrary;
    context._pthreadStruct = remotePthreadStruct;
    context.__pthread_set_self = &_pthread_set_self;
    context.thread_terminate = &thread_terminate;
    context.mach_thread_self = &mach_thread_self;
    context.pthread_create = &pthread_create;
    context.pthread_join = &pthread_join;
    context.dlopen = &dlopen;
    
    vm_size_t contextSize = sizeof(INJECT_CONTEXT);
    vm_address_t remoteContext;
    krr = vm_allocate(remoteTask, &remoteContext, contextSize, VM_FLAGS_ANYWHERE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = vm_write(remoteTask, remoteContext, &context, (mach_msg_type_number_t)contextSize);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    
    // 写入Code
    void* code = &stub_code_start;
    vm_size_t codeSize = (size_t)stub_code_end-(size_t)stub_code_start;
    vm_address_t remoteCode;
    krr = vm_allocate(remoteTask, &remoteCode, codeSize, VM_FLAGS_ANYWHERE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = vm_write(remoteTask, remoteCode, code, (mach_msg_type_number_t)codeSize);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    //codeSize = PAGE_SIZE;
    
    krr = vm_protect(remoteTask, remoteCode, codeSize, FALSE, VM_PROT_READ | VM_PROT_EXECUTE);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    char check[4]={0};
    vm_size_t readsize;
    //vm_read_overwrite(remoteTask, remoteCode+8, 4, check, &readsize);
    
    printf("code=%lx %x\n", remoteCode, *(uint32_t*)check);
    
    
    // 创建远程线程
    _STRUCT_ARM_THREAD_STATE64 state = {0};
    
    state.__lr = (size_t)0x7171717171717171;
    state.__sp = (size_t)(remoteStack + stackSize/2);
    state.__pc = (size_t)dlsym(RTLD_DEFAULT, "pthread_create_from_mach_thread");
    state.__x[0] = (size_t)remoteStack;
    state.__x[1] = (size_t)NULL;
    state.__x[2] = (size_t)dlsym(RTLD_DEFAULT, "chroot");
    state.__x[3] = (size_t)remoteLibrary;
    
    
    //state.__pc = find_blr_x0_gadget();
    state.__x[0] = (size_t)remoteLibrary;
    state.__x[16] = (size_t)SYS_chroot;
    state.__pc = find_syscall_gadget();
    state.__lr = find_blr_x19_gadget();
    state.__x[19] = state.__lr;
    //printf("scode=%llx %x", state.__pc, *(uint32_t*)state.__pc);
    
    printf("thread context, pc=%llx lr=%llx sp=%llx x:[%llx,%llx,%llx,%llx]\n", state.__pc, state.__lr, state.__sp,
           state.__x[0], state.__x[1], state.__x[2], state.__x[3]);
    
    
    // 启动线程
    thread_act_t remoteThread;
    krr = thread_create(remoteTask, &remoteThread);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_create, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = thread_set_state(remoteThread, ARM_THREAD_STATE64, (thread_state_t)&state, ARM_THREAD_STATE64_COUNT);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_set_state, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = thread_resume(remoteThread);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_resume, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    printf("Remote thread is running.\n");
    return 0;
    
    
    
    
    
    /////////////////////////
    
    
    
    
    
    mach_port_name_t exceptionPort;
    krr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &exceptionPort);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_port_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = mach_port_insert_right(mach_task_self(), exceptionPort, exceptionPort, MACH_MSG_TYPE_MAKE_SEND);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_port_insert_right, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = thread_set_exception_ports(remoteThread, EXC_MASK_BAD_ACCESS, exceptionPort,
                                   MACH_EXCEPTION_CODES|EXCEPTION_DEFAULT, ARM_THREAD_STATE64);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_set_exception_ports, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    krr = thread_resume(remoteThread);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_resume, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    printf("Remote thread is running.\n");
    
    mach_msg_header_t msghead[128];
    krr = mach_msg(&msghead, MACH_RCV_MSG | MACH_RCV_LARGE | MACH_MSG_TIMEOUT_NONE, 0, 0x4000, exceptionPort, 0, 0);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_msg, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = thread_terminate(remoteThread);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_terminate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    // 等待线程结束，释放资源
    
    thread_state_flavor_t flavor;
    mach_msg_type_number_t count;
    flavor = ARM_THREAD_STATE64;
    count = ARM_THREAD_STATE64_COUNT;
    mach_msg_type_number_t read;
    kern_return_t status;
    
    while (true)
    {
        read = count;
        status = thread_get_state(remoteThread, flavor, (thread_state_t)&state, &read);
        if(status == KERN_SUCCESS)
        {
            printf("thread running %llx\n", state.__pc);
            usleep(10000);
            continue;
        }
        else if(status == KERN_TERMINATED || status == MACH_SEND_INVALID_DEST)
        {
            break;
        }
        else
        {
            printf("error getting thread state: %x %s\n", status, mach_error_string(status));
            return 0;
        }
    }
    
    usleep(500*1000);
    
    krr = mach_port_destroy(mach_task_self(), exceptionPort);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_port_destroy, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    if(remoteThread)
        mach_port_deallocate(self, remoteThread);
    if(remoteCode)
        vm_deallocate(remoteTask, remoteCode, codeSize);
    if(remotePthreadStruct)
        vm_deallocate(remoteTask, remotePthreadStruct, pthreadStructSize);
    if(remoteLibrary)
        vm_deallocate(remoteTask, remoteLibrary, libraryLen);
    if(remoteContext)
        vm_deallocate(remoteTask, remoteContext, contextSize);
    if(remoteStack)
        vm_deallocate(remoteTask, remoteStack, stackSize);
    
    printf("Injected successfully!\n");
    
    return 0;
}