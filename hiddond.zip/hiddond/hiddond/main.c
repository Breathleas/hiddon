#include <stdio.h>
#include <dlfcn.h>
#include <spawn.h>
#include <mach/mach.h>
#include <mach/task.h>
#include <mach/port.h>
#include <mach/mach_traps.h>

#import <CoreFoundation/CoreFoundation.h>

#pragma pack(4)
typedef struct {
    mach_msg_header_t Head;
    mach_msg_body_t msgh_body;
    mach_msg_port_descriptor_t thread;
    mach_msg_port_descriptor_t task;
    NDR_record_t NDR;
} exception_raise_request; // the bits we need at least

typedef struct {
    mach_msg_header_t Head;
    NDR_record_t NDR;
    kern_return_t RetCode;
} exception_raise_reply;
#pragma pack()


int chrootinit() ;
bool change_rootvnode(const char* path, pid_t pid);

int get_spawn_attr_flags_offset()
{
    static offset = 0;
    static bool found = false;
    
    if(!found)
    {
        posix_spawnattr_t attr;
        posix_spawnattr_init(&attr);
        posix_spawnattr_setflags(&attr, 0x1234);
        printf("short size=%lu\n", sizeof(short));
        
        for(int i=0; i<32; i++) {
            if(((short*)attr)[i]==0x1234) {
                offset = i*sizeof(short);
                found = true;
                printf("find _spawn_attr_flags, i=%d, offset=%x\n", i, offset);
                break;
            }
        }
        
        posix_spawnattr_destroy(&attr);
    }
    
    return offset;
}


int mainchroot2(pid_t pid , char *library);

int handmsg(mach_port_name_t exceptionPort)
{
    kern_return_t krr;
    size_t readlen;
    
    mach_msg_header_t msghead[128];
    krr = mach_msg(&msghead, MACH_RCV_MSG | MACH_RCV_LARGE | MACH_MSG_TIMEOUT_NONE, 0, 0x4000, exceptionPort, 0, 0);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_msg, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    exception_raise_request* req = (exception_raise_request*)msghead;
    printf("got exception, id=%x, size=%x, bits=%x, lport=%x, rport=%x, vport=%x, body=%x, thread=%x task=%x\n",
           req->Head.msgh_id, req->Head.msgh_size, req->Head.msgh_bits, req->Head.msgh_local_port, req->Head.msgh_remote_port, req->Head.msgh_voucher_port, req->msgh_body.msgh_descriptor_count,
           req->thread.name, req->task.name);
    
    
    size_t read = ARM_THREAD_STATE64_COUNT;
    _STRUCT_ARM_THREAD_STATE64 state = {0};
    krr = thread_get_state(req->thread.name, ARM_THREAD_STATE64, (thread_state_t)&state, &read);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_get_state, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    printf("thread context, pc=%llx lr=%llx sp=%llx x:[%llx,%llx,%llx,%llx]\n", state.__pc, state.__lr, state.__sp,
           state.__x[0], state.__x[1], state.__x[2], state.__x[3]);
    
    
    static long pidaddr = 0;
    
    if(state.__pc & 0xFFF0000000000000)
    {
        
        //change_rootvnode("/", 1);
        
        if(pidaddr)
        {
            pid_t childpid=0;
            krr = vm_read_overwrite(req->task.name, pidaddr, sizeof(childpid), &childpid, &readlen);
            if(krr != KERN_SUCCESS)
            {
                printf("Failed: vm_read_overwrite, err=%d(%s)\n", krr, mach_error_string(krr));
                return 0;
            }
            
            printf("got child process, pid=%d\n", childpid);
            
            if(childpid)
            {
                change_rootvnode("/private/var/MobileSoftwareUpdate/mnt1", childpid);
                //mainchroot2(childpid , "/private/var/MobileSoftwareUpdate/mnt1");
                
                kill(childpid, SIGCONT);
            }
        }
        
        state.__pc &= ~0xFFF0000000000000;
    }
    else if(state.__pc==0x12345)
    {
        
        
        char path[255]={0};
        krr = vm_read_overwrite(req->task.name, state.__x[1], sizeof(path), path, &readlen);
        if(krr != KERN_SUCCESS)
        {
            printf("Failed: vm_read_overwrite, err=%d(%s)\n", krr, mach_error_string(krr));
            return 0;
        }
        
        printf("spawn, bin path=%s\n", path);
        
        if(memcmp(path, "/var/containers", sizeof("/var/containers")-1)==0
           || memcmp(path, "/private/var/containers", sizeof("/private/var/containers")-1)==0)
      {
        
        size_t attrpointer=0;
        krr = vm_read_overwrite(req->task.name, state.__x[3], sizeof(attrpointer), &attrpointer, &readlen);
        if(krr != KERN_SUCCESS)
        {
            printf("Failed: vm_read_overwrite, err=%d(%s)\n", krr, mach_error_string(krr));
            return 0;
        }
        
        printf("spawn, attr=%lx\n", attrpointer);
        
        size_t flagspointer = attrpointer+get_spawn_attr_flags_offset();
        
        
        short attrflags = 0;
        krr = vm_read_overwrite(req->task.name, flagspointer, sizeof(attrflags), &attrflags, &readlen);
        if(krr != KERN_SUCCESS)
        {
            printf("Failed: vm_read_overwrite, err=%d(%s)\n", krr, mach_error_string(krr));
            return 0;
        }
        
        printf("spawn, attrflags=%x\n", attrflags);
        
        attrflags |= POSIX_SPAWN_START_SUSPENDED;
        
        krr = vm_write(req->task.name, flagspointer, &attrflags, sizeof(attrflags));
        if(krr != KERN_SUCCESS)
        {
            printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
            return 0;
        }
        
        pidaddr = state.__x[0];
        state.__lr |= 0xFFF0000000000000;
            
      }
        
        state.__pc = dlsym(RTLD_DEFAULT, "posix_spawnp");
        
    }
    
    
    krr = thread_set_state(req->thread.name, ARM_THREAD_STATE64, (thread_state_t)&state, ARM_THREAD_STATE64_COUNT);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_set_state, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    
    exception_raise_reply reply = {0};
    reply.Head.msgh_bits = req->Head.msgh_bits & MACH_MSGH_BITS_REMOTE_MASK;
    reply.Head.msgh_size = (mach_msg_size_t)sizeof(reply);
    reply.Head.msgh_remote_port = req->Head.msgh_remote_port;
    reply.Head.msgh_local_port = MACH_PORT_NULL;
    reply.Head.msgh_id = req->Head.msgh_id + 0x64;
    
    reply.NDR = req->NDR;
    reply.RetCode = KERN_SUCCESS;
    
    
    krr = mach_msg(&reply.Head, 1, reply.Head.msgh_size, 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_msg, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    mach_port_deallocate(mach_task_self_, req->thread.name);
    mach_port_deallocate(mach_task_self_, req->task.name);
    
}

uint64_t find_syscall_gadget();
uint64_t find_blr_x19_gadget();
int main (int argc, const char * argv[])
{
    chrootinit();
    
//    if(!(find_blr_x19_gadget() && find_syscall_gadget()))
//        return 0;
    
    extern char **environ;
    for(int i=0; environ[i]; i++)
    {
         printf("env2 <%d>: %s\n", i, environ[i]);
    }
    
    
    printf("_spawn_attr_flags_offset=%x\n", get_spawn_attr_flags_offset());
    
    if(argc!=2) {
        printf("invalid args!\n");
        return -1;
    }
    
    pid_t pid = atoi(argv[1]);
    
    task_t target_task_port;
    
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &target_task_port);
    if (kr != KERN_SUCCESS) {
        printf("Failed to get task for pid %u!\n", pid);
        return -1;
    }
    
    printf("got task=%x for pid=%d\n", target_task_port, pid);
    
    
    struct ios_execp_info {
        exception_mask_t masks[EXC_TYPES_COUNT];
        mach_port_t ports[EXC_TYPES_COUNT];
        exception_behavior_t behaviors[EXC_TYPES_COUNT];
        thread_state_flavor_t flavors[EXC_TYPES_COUNT];
        mach_msg_type_number_t count;
    };
    
    struct ios_execp_info info = {0};
    
    task_get_exception_ports(target_task_port, EXC_MASK_ALL,
                             info.masks, &info.count, info.ports, info.behaviors, info.flavors);
    
    printf("got exception ports count=%d\n", info.count);
    
    for (int i = 0;i < info.count; i++)
    {
        printf("port[%d] mask=%08X port=%08X behavior=%08X flavor=%08X\n", i,
               info.masks[i], info.ports[i],
               info.behaviors[i], info.flavors[i]);
    }
    
    
    
        kern_return_t err;
        mach_msg_type_number_t region_count = VM_REGION_BASIC_INFO_COUNT_64;
        memory_object_name_t object_name = MACH_PORT_NULL; /* unused */
        mach_vm_size_t target_first_size = 0x1000;
        mach_vm_address_t target_first_addr = 0x0;
        struct vm_region_basic_info_64 region = {0};
        err = vm_region_64(target_task_port,
                             &target_first_addr,
                             &target_first_size,
                             VM_REGION_BASIC_INFO_64,
                             (vm_region_info_t)&region,
                             &region_count,
                             &object_name);
        
        if (err != KERN_SUCCESS) {
            printf("failed to get the region\n");
            return -1;
        }
        
        printf("executable address=%llx\n", target_first_addr);
    
//    size_t hack1 = target_first_addr + 0x2D930;
//    size_t hack2 = target_first_addr + 0x2D790;
//    size_t hack3 = target_first_addr + 0x2D860;
    
    
    size_t hack4 = target_first_addr + 0x48178; //posix_spawn
    size_t hack5 = target_first_addr + 0x48180; //posix_spawnp
    size_t hack6 = target_first_addr + 0x4c1d0; //_csops
    size_t hack7 = target_first_addr + 0x4c1d8; //_csops_audittoken
    size_t hack8 = target_first_addr + 0x4c840; //posix_spawnp
    size_t hack9 = target_first_addr + 0x4c8e8; //_sandbox_check_by_audit_token
     //
    
    
    
    size_t sign=0;
    size_t readlen;
    kern_return_t krr = vm_read_overwrite(target_task_port, hack4, sizeof(sign), &sign, &readlen);
    printf("sign=%lx\n", sign);
    
    size_t newvalue = dlsym(RTLD_DEFAULT, "posix_spawn");
    krr = vm_write(target_task_port, hack4, &newvalue, sizeof(newvalue));
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    newvalue = 0x12345;//dlsym(RTLD_DEFAULT, "posix_spawnp");
    krr = vm_write(target_task_port, hack5, &newvalue, sizeof(newvalue));
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    newvalue = dlsym(RTLD_DEFAULT, "posix_spawnp");
    krr = vm_write(target_task_port, hack8, &newvalue, sizeof(newvalue));
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }

    newvalue = dlsym(RTLD_DEFAULT, "csops");
    krr = vm_write(target_task_port, hack6, &newvalue, sizeof(newvalue));
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    newvalue = dlsym(RTLD_DEFAULT, "csops_audittoken");
    krr = vm_write(target_task_port, hack7, &newvalue, sizeof(newvalue));
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    newvalue = dlsym(RTLD_DEFAULT, "sandbox_check_by_audit_token");
    krr = vm_write(target_task_port, hack9, &newvalue, sizeof(newvalue));
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    
    
    
    long* data = malloc(0x60000);
    
    krr = vm_read_overwrite(target_task_port, target_first_addr, 0x60000, data, &readlen);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: vm_read_overwrite, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    printf("got data=%lx, size=%lx, sign=%lx\n", data, readlen, *data);
    
    for(int i=0; i<0x60000/sizeof(long); i++)
    {
        long offset = i*sizeof(long);
        long item = data[i];
        switch(item)
        {
            case 0x12345:
            case 0x23456:
            case 0x34567:
            case 0x45678:
            case 0x56789:
                printf("found[%d] %lx in offset:%lx\n", i, item, offset);
                break;
                
            default:
                break;
                
        }
    }
    
    
    
    mach_port_name_t exceptionPort;
    krr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &exceptionPort);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_port_allocate, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    krr = mach_port_insert_right(mach_task_self(), exceptionPort, exceptionPort, MACH_MSG_TYPE_MAKE_SEND);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: mach_port_insert_right, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    krr = task_set_exception_ports(target_task_port, EXC_MASK_BAD_ACCESS, exceptionPort,
                                     MACH_EXCEPTION_CODES|EXCEPTION_DEFAULT, ARM_THREAD_STATE64);
    if(krr != KERN_SUCCESS)
    {
        printf("Failed: thread_set_exception_ports, err=%d(%s)\n", krr, mach_error_string(krr));
        return 0;
    }
    
    
    while(true)
    {

        handmsg(exceptionPort);
       
        
//        fd_set rfds;
//        struct timeval tv;
//        int ch = 0;
//        
//        FD_ZERO(&rfds);
//        FD_SET(0, &rfds);
//        tv.tv_sec = 0;
//        tv.tv_usec = 10; //设置等待超时时间
//        
//        //检测键盘是否有输入
//        if (select(1, &rfds, NULL, NULL, &tv) > 0)
//        {
//            printf("got, exit!\n");
//            
//            printf("now restore...\n");
//            
//            size_t newvalue2 = dlsym(RTLD_DEFAULT, "posix_spawnp");
//            krr = vm_write(target_task_port, hack8, &newvalue2, sizeof(newvalue));
//            if(krr != KERN_SUCCESS)
//            {
//                printf("Failed: vm_write, err=%d(%s)\n", krr, mach_error_string(krr));
//                return 0;
//            }
//            
//            printf("clear exception port...\n");
//            krr = task_set_exception_ports(target_task_port, EXC_MASK_BAD_ACCESS, MACH_PORT_NULL,
//                                           MACH_EXCEPTION_CODES|EXCEPTION_DEFAULT, ARM_THREAD_STATE64);
//            if(krr != KERN_SUCCESS)
//            {
//                printf("Failed: thread_set_exception_ports, err=%d(%s)\n", krr, mach_error_string(krr));
//                return 0;
//            }
//            
//            printf("now exit...\n");
//            
//            break;
//        }
        
        
    }
    
    return 0;
}



